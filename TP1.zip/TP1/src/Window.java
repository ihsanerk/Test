/**La classe window represente l'interface graphique et console*/


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Window extends JFrame{
	/**
	 * les boutons pour appeler les methodes
	 */
	private static final long serialVersionUID = 1L;
	private JButton b1 = new JButton ("Afficher valeurs du tableau");
	private JButton b2 = new JButton ("Remplire le tableau les arguments de la ligne de commande");
	private JButton b3 = new JButton ("Remplire al�atoirement le tableau");
	private JButton b4 = new JButton ("Trier le tableau par ordre croissant");
	private JButton b5 = new JButton ("Calculer le minimum du tableau");
	private JButton b6 = new JButton ("Calculer le maximum du tableau");
	private JButton b7 = new JButton ("Calculer la moyenne du tableau");
	private JButton b8 = new JButton ("Chercher un nombre dans le tableau");

	/**instanciation d'un objet Class1*/
	Class1 class1 = new Class1 ();

	public Window (final String[] argument) {
		/**creation interface graphique*/
		this.setTitle("TP1 exo5");
		this.setSize(450,300);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.getContentPane().setLayout(new FlowLayout());
		this.getContentPane().add(b1);
		this.getContentPane().add(b2);
		this.getContentPane().add(b3);
		this.getContentPane().add(b4);
		this.getContentPane().add(b5);
		this.getContentPane().add(b6);
		this.getContentPane().add(b7);
		this.getContentPane().add(b8);
		this.setBackground(Color.red);


		/**creation tableau*/
		final int [] tab=new int[argument.length] ; 
		/**remplir tableau avec ligne de commande*/
		class1.remplirTableau(argument,tab);

		/**appeler methodes pour chaque bouton*/
		b1.addActionListener (new ActionListener(){

			public void actionPerformed (ActionEvent arg0){


				class1.parcourirTableau(tab);

			}
		});
		b2.addActionListener (new ActionListener(){

			public void actionPerformed (ActionEvent arg0){
				class1.remplirTableau(argument,tab);
				class1.parcourirTableau(tab);

			}
		});
		b3.addActionListener (new ActionListener(){

			public void actionPerformed (ActionEvent arg0){
				class1.remplirTableauAleatoire (tab);
			}
		});
		b4.addActionListener (new ActionListener(){
			public void actionPerformed (ActionEvent arg0){
				class1.trierTableau(tab);
			}
		});   
		b5.addActionListener (new ActionListener(){

			public void actionPerformed (ActionEvent arg0){
				int minValue=0;
				minValue=class1.minTableau (tab);
				System.out.println("le nombre min est "+ minValue);
			}
		});
		b6.addActionListener (new ActionListener(){

			public void actionPerformed (ActionEvent arg0){
				int maxValue = 0;
				maxValue=class1.maxTableau (tab);
				System.out.println("le nombre max est "+ maxValue);
			}
		});
		b7.addActionListener (new ActionListener(){

			public void actionPerformed (ActionEvent arg0){
				float moyValue=0;
				moyValue=class1.moyTableau (tab);
				System.out.println("la moyenne est "+ moyValue);
			}
		});
		b8.addActionListener (new ActionListener(){

			public void actionPerformed (ActionEvent arg0){
				class1.rechercheTableau(tab);
			}
		});


		/**afficher*/
		this.setVisible(true);

	}


}
