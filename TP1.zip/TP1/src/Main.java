

/**la classe main contient le main*/
public class Main {
	public static void main (String[] args) {

		/**double exception s'il nya pas d'argument ou si les arguments ne sont pas entiers sortir du programme*/
		try {
			if(args[0]!=null){

				new  Window (args);}
		}
		catch (ArrayIndexOutOfBoundsException e2) {
			System.out.print("il n'y a pas d'argument");
			System.exit(0);
		}
		catch (NumberFormatException e1){
			System.out.print("les arguments ne sont pas des entiers");
			System.exit(0);
		}

	}
}
